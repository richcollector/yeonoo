package com.noo.wms.outstock.controller;

public class OutstockRestController {

}
