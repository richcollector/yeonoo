package com.noo.wms.test.mapper;

import java.util.ArrayList;

import com.noo.wms.vo.TestVo;

public interface TestSQLMapper {
	public ArrayList<TestVo> selectMember();
}
